package acadglidassignment;

import java.io.IOException;
import java.util.Scanner;

public class Swapping {
	public static void main(String[] args) throws IOException {
		try {
			Scanner objScanner = new Scanner(System.in);
			System.out.println("\n Please enter First number");
			int numA = objScanner.nextInt();
			System.out.println("\n Please enter second number");
			int numB = objScanner.nextInt();
			numB = numA * numB;
			numA = numB / numA;
			numB = numB / numA;
			System.out
					.println("\n After swapping first number is" + numA + "\n After swapping second number is" + numB);
			objScanner.close();
		} catch (java.util.InputMismatchException ex) {
			System.out.println("Please enter a valid input");
		}

	}

}
